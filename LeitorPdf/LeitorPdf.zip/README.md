# LeitorPdf

Projeto de extração de dados de faturas em pdf para inserção desses dados em um arquivo excel

## WARNING

You are using an outdated version of the template which is no longer recommended.

While this template works and is valid, it is strongly recommended to create a new project with the latest template version.

Please refer to our [documentation page](https://documentation.botcity.dev/tutorials/python-automations/desktop/).
